const express = require("express");
const router = express.Router();
const controller = require("../controllers/studentController");

router.get("/", controller.getHome);
router.post("/", controller.createStudent);
router.get("/students", controller.getStudents);
router.get("/success", controller.successPage);
router.get("/students/:id/edit", controller.editStudentForm);
router.post("/students/:id/edit", controller.updateStudent);
router.post("/students/:id/delete", controller.deleteStudent);



module.exports = router;
